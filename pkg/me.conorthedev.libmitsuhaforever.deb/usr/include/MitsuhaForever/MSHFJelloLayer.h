#import <UIKit/UIKit.h>

@interface MSHFJelloLayer : CAShapeLayer

@property BOOL shouldAnimate;

@end