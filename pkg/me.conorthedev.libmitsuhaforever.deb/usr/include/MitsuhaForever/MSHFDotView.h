#import "MSHFView.h"
#import <UIKit/UIKit.h>

@interface MSHFDotView : MSHFView

@property(nonatomic, assign) CGFloat barSpacing;

@end