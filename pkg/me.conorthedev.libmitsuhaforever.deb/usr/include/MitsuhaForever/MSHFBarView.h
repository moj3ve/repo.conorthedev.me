#import "MSHFView.h"
#import <UIKit/UIKit.h>

@interface MSHFBarView : MSHFView

@property(nonatomic, assign) CGFloat barCornerRadius;
@property(nonatomic, assign) CGFloat barSpacing;

@end